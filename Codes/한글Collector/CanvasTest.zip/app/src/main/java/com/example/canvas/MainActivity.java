package com.example.canvas;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;


public class MainActivity extends AppCompatActivity {

    protected int curr = 1;
    private String temp;
    private Button btn_next, btn_erase, btn_send, btn_confirm, btn_getData;
    private TextView tv_char, tv_cur;
    protected static String sentence1 = "";
    protected String sentence2[] = new String[5];
    protected static String str[] = new String[5];
    protected static int min[] = new int[5];//min획수
    protected static int max[] = new int[5];//max획수
    protected static int uni[] = new int[5];//
    protected Boolean bl_isSend = false;
    AlertDialog.Builder end, end2;// 알림창의 객체 선언
    protected Socket s = null;
    BufferedReader in;
    PrintWriter out = null;
    DataOutputStream dos = null;
    DataInputStream dis;
    Thread thread, thread2, thread3;
    int index = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        AlertDialog.Builder builderEND = new AlertDialog.Builder(this); //토픽순서 Dialog
        builderEND.setTitle("학습 프로그램 전송 테스트");
        builderEND.setMessage("한번 더 하시겠습니까?");

        builderEND.setPositiveButton("예",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        MyGraphicView m = findViewById(R.id.canvas);

                        //지금까지의 모든 쓰레드 죽이기
                        thread.interrupt();
                        thread2.interrupt();
                        thread3.interrupt();

                        // 초기화
                        index = 0;
                        curr = 1;

                        // 초기화 함수
                        Intro();
                    }
                });

        builderEND.setNegativeButton("아니오",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //알림창 끄기
                        dialogInterface.cancel();
                        //앱 종료
                        MainActivity.this.finish();
                    }
                });
        final AlertDialog endDialog = builderEND.create();
        setTitle("DI Project - 한글 획 데이터 수집");

        btn_next = findViewById(R.id.btn_next);     // 다음 그림으로 넘어가기
        btn_erase = findViewById(R.id.btn_erase);   // 내용 지우기
        btn_send = findViewById(R.id.btn_send);       // 좌표 전송하기
        btn_getData = findViewById(R.id.btn_getData); //서버로 부터 학습 데이터 얻어오기
        tv_char = findViewById(R.id.tv_char);       // 학습할 문자
        tv_cur = findViewById(R.id.tv_cur);         // 현재 위치/문자 갯수


        //소켓 열고 스레드 실행
        //서버와의 연결
        Intro();

        //데이터 얻어오기 버튼을 눌렀을 때
        btn_getData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.v("socket 연결", "전");

                thread3 = new Thread() {
                    public void run() {
                        //서버와의 연결을 통해서 데이터 얻어오기
                        try {
                            //스트림 설정
                            dis = new DataInputStream(s.getInputStream());

                            Log.v("socket 연결", "완료");

                            for (int i = 0; i < 5; i++) {
                                //글자 받아서 저장
                                str[i] = dis.readUTF();
                                sentence1 += str[i];

                                //최대 획수 저장
                                max[i] = dis.readInt();

                                //최저 획수 저장
                                min[i] = dis.readInt();

                                //최대 획수 저장
                                uni[i] = dis.readInt();

                                Log.v("str :", sentence1);
                            }
                        } catch (Exception e) {
                            System.out.println(e.getMessage());
                        }
                    }
                };
                //쓰레드 시작
                thread3.start();


                //sentence2=sentence1.split("");
                //tv_char.setText("["+sentence1+"]");
                try {
                    thread3.sleep(50);
                } catch (Exception e) {
                }

                tv_char.setText("[" + str[index] + "]");

            }
        });

        //다음으로 버튼 클릭 시
        btn_next.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                //글자 데이터에 대한 전처리 시작!
                MyGraphicView m = findViewById(R.id.canvas);

                final int temp_index=m.index;
                Log.d("m.index :",Integer.toString(m.index));
                m.index=0;

                //그려서 얻은 획순과 서버로 부터 받은 획순 비교
                //최저획순과 같은 경우 OR 최대획순과 같은 경우  둘 다 비교!
                if (m.count >= min[index] && m.count <= max[index]) {
                    //다음으로 넘어가기
                    //우상단 진행현황 최신화 부분
                    curr++;

                    //새롭게 생성한 쓰레드
                    //데이터 전송시 필요하다.
                    thread2 = new Thread() {
                        public void run() {

                            MyGraphicView m = findViewById(R.id.canvas);
                            m.Send_OK = true;   //좌표 전송해도 좋다는 플래그

                            //보낼 좌표가 들어있는 배열들 복사해서 가져오기
                            //x좌표 y좌표가 들어있는 배열들
                            float[] x = m.getarray_x();
                            float[] y = m.getarray_y();

                            // m.Print_Coordinates();


                            // 좌표 전송
                            try {
                                //출력 스트림 생성
                                dos = new DataOutputStream(s.getOutputStream());

                                // 인덱스 보내기
                                dos.writeInt(temp_index);

                                // 문자 (ex.가) 보내기
                                dos.writeInt(uni[index]);
                                index++;

                                // 배열(좌표) 전송
                                for (int n = 0; n < temp_index; n++) {
//                                    if (x[n] == 0.0)
//                                        break;

                                    dos.writeFloat(x[n]);
                                    dos.writeFloat(y[n]);
                                }

                                dos.flush();
                                Log.d("curr : ", ""+curr);
                                // 학습이 끝났을 때
                                if (curr > 5) {
                                    Log.d("curr : ", "curr over 5!");
                                    new Thread(new Runnable() {
                                        @Override public void run() {
                                            runOnUiThread(new Runnable() {
                                                public void run() {
                                                    endDialog.show();//알림창 띄우기
                                                }
                                            });
                                        }
                                    }).start();
                                    YorN();
                                    try {
                                        Log.v("소켓 닫음 : ", "");
                                        //소켓 닫기->새로운 연결을 위해서 기존의 소켓은 닫는다
                                        s.close();

                                        Log.v("소켓 닫고 YorN 함수 호출 해보자 : ", "");
                                        // 학습 종료창 띄우는 함수 호출
                                    } catch (Exception e) {}
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    };
                    //스레드 실행
                    thread2.start();

                    Log.i("test","");
                    // 학습이 끝나지 않았을 때
                    if (curr <= str.length) {
                        temp = curr + "/" + 5;
                        tv_cur.setText(temp);
                        tv_char.setText("[" + str[curr-1] + "]");
                        m.count = 0;
                    }

//                    try {
//                        Thread.sleep(50);
//                    }
//                    catch (Exception e){}
                } else    //일치 하지 않은 경우
                {
                    //메세지 출력
                    Toast.makeText(MainActivity.this, "너 똑바로 안썼지....?" , Toast.LENGTH_SHORT).show();
                    m.count = 0;

                }

                //저장한 획 데이터를 서버로 전송하는 부분 구현 예정

                //화면 초기화
                //다음 글씨를 입력하기 위함
                //m.index = 0;
                m.isErase = true;
                m.invalidate();

            }

        });

        //내용 지우기 버튼 눌렀을 때
        btn_erase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // isErase = false로 설정한 후, 캔버스 다시 그리기
                MyGraphicView canvas = findViewById(R.id.canvas);

                //좌표 저장된 배열 가져와서 초기화 하기
                //다시 새롭게 얻어진 좌표 저장하기 위해서
                for (int i = 0; i < 500; i++) {
                    canvas.x[i] = 0;
                    canvas.y[i] = 0;
                }

                canvas.index = 0;
                canvas.isErase = true;
                canvas.invalidate();


            }
        });


    }

    //서버와의 연결 시도
    protected void Intro() {
        //현재 진행 상황 업데이트 및 초기화
        temp = curr + "/" + str.length;
        tv_cur.setText(temp);
        tv_char.setText("학습 데이터를 받아오세요");
        //연결 전용 스레드 생성
        thread = new Thread() {
            public void run() {
                try {
                    //소켓을 생성&서버와의 연결 시도
                    s = new Socket("117.17.142.132", 9304);
                } catch (IOException e)//예외 처리
                {
                    e.printStackTrace();
                }
            }
        };
        thread.start();//스레드 시작
    }

    //인덱스 & 배열 초기화
//    protected void Clear()
//    {
//        MyGraphicView m=new
//    }

    @Override
    protected void onStop() {  //앱 종료시 실행
        super.onStop();
        try {
            s.close(); //소켓닫기
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    protected void YorN() {
        Log.d("curr : ", "Y or N 호출");

        //종료 선택 창 띄우기

    }

}


class MyGraphicView extends View {

    Paint paint = new Paint();//paint 객체
    Path path = new Path();//경로 기록 객체 선언

    Boolean isErase = false;
    Boolean Send_OK = false;

    //최대 좌표 저장 개수 : 300개
    float[] x = new float[500];

    float[] y = new float[500];
    int index = 0, count = 0;

    //배열 복제하기
    //획 데이터가 저장된 배열
    public float[] getarray_x() {
        return x.clone();
    }

    public float[] getarray_y() {
        return y.clone();
    }

    // xml에서 해당 클래스를 사용할때는 Context, AttributeSet을 인자로 갖는 생성자가 있어야만 한다
    public MyGraphicView(Context context, AttributeSet attrs) {
        //super(context);
        super(context, attrs);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(13f);

    }

    //그림 그리기 함수
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        //paint.setColor(Color.GREEN);

        // isErase == true, 지우기 버튼 눌렀을 때
        if (isErase) {
            path.reset();

            isErase = false;
        }

        //Send_OK==true,
        else if (Send_OK) {
            Send_OK = false;
            //dataSave(x,y);
        } else canvas.drawPath(path, paint);   // path에 저장된 경로 그대로 그리기
    }

    //저장 가능한 배열 크기 넘게 좌표가 입력될 때
    //출력되는 알림창
    public boolean onTouchEvent(MotionEvent event) {
        final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this.getContext());

        // 제목셋팅
        alertDialogBuilder.setTitle("오류 발생");
        // AlertDialog 셋팅
        alertDialogBuilder
                .setMessage("더 이상 그림을 그릴 수 없습니다")

                .setCancelable(false)

                .setPositiveButton("다시 그리기",
                        new DialogInterface.OnClickListener() {
                            public void onClick(
                                    DialogInterface dialog, int id) {
                                // 그림을 지운다
                                MyGraphicView canvas2 = findViewById(R.id.canvas);
                                canvas2.isErase = true;
                                canvas2.invalidate();
                            }
                        })
                .setNegativeButton("계속하기",
                        new DialogInterface.OnClickListener() {
                            public void onClick(
                                    DialogInterface dialog, int id) {
                                // 다이얼로그를 취소한다
                                alertDialogBuilder.show();
                            }
                        });

        // 다이얼로그 생성
        AlertDialog alertDialog = alertDialogBuilder.create();


        switch (event.getAction()) {
            //손가락으로 화면을 누르기 시작했을 때 할일
            case MotionEvent.ACTION_DOWN:
                //좌표 선언 및 터치 좌표 얻어오기
                float start = (float) event.getX();
                float end = (float) event.getY();
                //좌표 위치 계속 바뀜
                path.moveTo(start, end);
                break;

            //터치 후 손가락을 움직일 때
            case MotionEvent.ACTION_MOVE:

                float s = event.getX();//좌표 얻고
                x[index] = s;          //좌표 저장
                float e = event.getY();//좌표 얻고
                y[index++] = e;          //좌표 저장
                //좌표 위치 계속 기존 위치에 덧붙이기
                path.lineTo(s, e);

                //Error
                if (index == 499)//배열 다 찼을 때
                {
                    alertDialog.show();//알림창 출력하기
                }
                break;

            // 손가락을 화면에서 뗄 때
            case MotionEvent.ACTION_UP:
                count++;//획순을 저장하는 변수
                float ss = event.getX();//좌표 얻고
                x[index] = ss;          //좌표 저장
                float ee = event.getY();//좌표 얻고
                y[index++] = ee;          //좌표 저장

                // 다음 좌표에 떼었다는 걸 알려주기 위해 (0.0)을 저장해준다

                x[index] = 0;
                y[index++] = 0;
                performClick();
                break;

            default:
                return false;
        }
        invalidate();
        return true;
    }


    @Override
    public boolean performClick() {
        return super.performClick();
    }


    public void Print_Coordinates() {
        MyGraphicView m = findViewById(R.id.canvas);

        //보낼 좌표가 들어있는 배열들 복사해서 가져오기
        //x좌표 y좌표가 들어있는 배열들
        float[] x = m.getarray_x();
        float[] y = m.getarray_y();

        for (int i = 0; i < 500; i++) {
            Log.v("x cord", String.valueOf(x[i]));
            Log.v("y cord", String.valueOf(y[i]));
        }

    }
}
