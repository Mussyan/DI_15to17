package Package;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;

import javax.imageio.ImageIO;

public class ServerReceiveThread extends Thread {

	Socket s;
	float msg;
	protected InputStream in;
	protected DataInputStream dis;
	protected DataOutputStream dos;
	protected BufferedReader br;
	protected BufferedImage img;

	Dataset ds = new Dataset();
	
	int uni, numOfLine = 0; 
	// 현재 글자에 해당하는 유니코드, 획 수
	int numOfLineIndex; //연산에 쓰기 편하게 (획 수-1) 저장
	int cnt1, cnt2; //초성 끊을 지점, 중성 끊을 지점
	int index = 0, count = 0;
	int ba_index = 0;
	public static final String dir = "C:\\Users\\gunyoungkim\\Desktop\\img2\\"; 	float max_x = 0, max_y = 0, min_x = 2000, min_y = 2000, size_x = 0, size_y = 0, size = 0;
	float most_far_x;
	float most_far_y;
	float initial, medial, last;

	float[] x, y, before_x, before_y, after_x, after_y, distance_x, distance_y;
	float result;

	double[] distance;


	public ServerReceiveThread(Socket s) {
		System.out.println("서버 리시브 스레드 시작");
		this.s = s;

	}

	@Override
	public void run() {
		try {

			System.out.println("Stream is ready");
			dis = new DataInputStream(s.getInputStream());

			while (true) {
				index = dis.readInt();
				numOfLine = 0;
				// 인덱스와 좌표를 가져온다.
				System.out.println("서버에서 보낸 좌표");
				System.out.printf("index = %d\n", index);

				// 안드로이드에서 인덱스를 전송했을 때
				if (index != 0) {

					// 유니코드 받아오기
					uni = dis.readInt() - 44032;

					x = new float[index];
					y = new float[index];

					before_x = new float[index];
					before_y = new float[index];

					after_x = new float[index];
					after_y = new float[index];

					distance_x = new float[index];
					distance_y = new float[index];
					distance = new double[index];

					// 보낸 좌표 저장 완료
					for (int i = 0; i < index; i++) {
						x[i] = dis.readFloat();
						if (x[i] > max_x && i != index - 1)
							max_x = x[i];
						if (x[i] < min_x)
							min_x = x[i];

						y[i] = dis.readFloat();
						if (y[i] > max_y && i != index - 1)
							max_y = y[i];
						if (y[i] < min_y)
							min_y = y[i];
						System.out.printf("%f  %f   ", x[i], y[i]);
					}

					// 글자를 그린 범위
					size_x = max_x - min_x;
					size_y = max_y - min_y;

					System.out.println("");

					// 좌표 순회하기 (획 나누기)
					for (int i = 0; i < index; i++) {
						// 분기점을 만났을 때
						if (x[i] == 0.0 && y[i] == 0.0) {
							// 0.0이 나온 이전의 좌표를 기억하기
							numOfLine++;
							before_x[ba_index] = x[i - 1];
							before_y[ba_index] = y[i - 1];

							if (i + 1 < index) {
								// 0.0이 나온 이후의 좌표를 기억하기
								after_x[ba_index] = x[i + 1];
								after_y[ba_index] = y[i + 1];
							} else {
								after_x[ba_index] = 0;
								after_y[ba_index] = 0;
							}
							ba_index++;

						} else
							continue;
					}
					System.out.println("");
					ba_index = 0;
				}				

				max_x = 0;
				max_y = 0;

				min_x = x[0];
				min_y = y[0];

				numOfLineIndex = numOfLine - 1; //연산에 쓰기 편하게
				
				String first, second, third; //각 초성, 중성, 종성
				
				switch (uni / 588) { // 전체 획 데이터 중 초성에 대한 부분만 저장하기 위한 조건문
				case 0: // 초성이 ㄱ 일 때
					first = "ㄱ";
					if (isSimilar(0,1)==false) //함수 설명은 아래에
						cnt1 = 0;
					else //ㄱ이 2획인 경우(첫 획의 끝점과 두 번째 획의 시작점이 유사한가?)
						cnt1 = 1;
					break;
				case 1: // ㄲ
					first = "ㄲ";
					if(Math.abs(before_y[0] - after_y[0]) < size_y / 10)
						cnt1 = 3; // ㄲ이 2획인 경우(첫 획의 끝점과 두 번째 획의 시작점의 y좌표가 유사한가?)
					else 
						cnt1 = 1; 
					break;
				case 2: // ㄴ
					first = "ㄴ";
					if (isSimilar(0,1)==false)
						cnt1 = 0; // ㄴ이 2획인 경우(첫 획의 끝 점과 두 번째 획의 시작점의 y좌표가 가까운가?)
					else
						cnt1 = 1;
					break;
				case 3: // ㄷ 원래 2~3획이었으나 현실적으로 1~2획으로 변동
					first = "ㄷ";
					if (Math.abs(y[0] - after_y[0]) < size_y / 10)
						cnt1 = 1; // ㄷ이 2획인 경우(첫 획의 시작점과 두 번째 획의 시작점의 x좌표가 먼가?)
					else 
						cnt1 = 0;
					break;
				case 4: // ㄸ ㄷ과 유사하게 3~6에서 2~4로 변동
					first = "ㄸ";
					if (Math.abs(x[0] - after_x[0]) < size_x / 10)
						cnt1 = 3;// ㄸ이 2획인 경우(첫 획 시작점과 두 번째 획 시작점의 x좌표가 유사한가?)
					else
						cnt1 = 1;
					break;
				case 5: // ㄹ
					first = "ㄹ";
					if (Math.abs((before_y[0] - before_y[1]) + (after_y[0] - after_y[1])) < size_y / 5)
						cnt1 = 2; // ㄹ이 3획인 경우(1-2획의 끝 점의 y좌표, 2-3획 시작점의 y좌표가 유사한가?)
					else
						cnt1 = 0;
					break;
				case 6: // ㅁ
					first = "ㅁ";
					if (Math.abs((x[0] - after_x[0]) + (x[0] - after_x[1])) < size_x / 5)
						cnt1 = 2; // ㅁ이 3획인 경우(1-2-3획의 시작점의 x좌표가 유사한가?)
					else
						cnt1 = 1; // 4획에 쓰는사람은 현실적으로 배제
					break;
				case 7: // ㅂ
					first = "ㅂ";
					if (x[0] - after_x[1] < size_x/20)
						cnt1 = 1;// ㅂ이 4획인 경우(3획의 시작점 y좌표가 1획의 시작점 y좌표보다 큰가?)
					else
						cnt1 = 3;
					break;
				case 8: // ㅃ
					first = "ㅃ";
					if (x[0] - after_x[1] < size_x/20)
						cnt1 = 3; // ㅂ이 8획인 경우(ㅂ 구분 할 때와 같음) + 보정값
					else
						cnt1 = 7;
					break;
				case 9: // ㅅ
					first = "ㅅ";
					//ㅅ의 두번째 획은 대부분 첫번째 획 길이의 중간 지점에 가깝게 찍히게 된다.
					if(Math.abs(after_y[0]-((y[0]+before_y[0])/2))<size_y/10)
						cnt1 = 1; // ㅅ이 2획인 경우(2획 시작점의 x좌표가 1획 시작점의 x좌표보다 왼쪽인가?)
					else
						//ㅅ이 1획인 경우
						cnt1=0;
					break;
				case 10: // ㅆ->ㅅ경우 2번 생각하면 되지 않을까요?
					first = "ㅆ";
					if(Math.abs(after_y[0]-((y[0]+before_y[0])/2))<size_y/10)
					{
						//첫 ㅅ의 2번째 획의 y좌표와 비슷한지 비교
						if((Math.abs(after_y[0])-Math.abs(after_y[1]))<size_y/10)
							cnt1=3;
					}
					else
						//ㅅ을 1획씩 2번 쓰는 경우
						cnt1=1;
					break;
				case 11: // ㅇ
					first = "ㅇ";
					cnt1 = 0; // ㅇ = 1획 반박불가
					break;
				case 12: // ㅈ
					first = "ㅈ";
					if (Math.abs(y[0] - after_y[0]) < size_y / 20)
						cnt1 = 2; // ㅈ이 3획인 경우(2획의 시작점의 y좌표가 1획 시작점의 y좌표와 유사한가?)
					else
						cnt1 = 1;
					break;
				case 13: // ㅉ
					first = "ㅉ";
					if (Math.abs(y[0] - after_y[0]) < size_y / 20)
						cnt1 = 5; // ㅈ이 6획인 경우(ㅈ같다)
					else
						cnt1 = 3;
					break;
				case 14: // ㅊ
					first = "ㅊ";
					if (Math.abs(y[1] - after_y[1]) < size_y / 20)
						cnt1 = 3; // ㅊ이 3획인 경우(ㅈ에서 인용)
					else
						cnt1 = 2;
					break;
				case 15: // ㅋ
					first = "ㅋ";
					cnt1 = 1; // ㅋ = 2획 반박불가
					break;
				case 16: // ㅌ
					first = "ㅌ";
					if (Math.abs((x[0] - after_x[0]) + (x[0] - after_x[1])) < size_x / 5)
						cnt1 = 2; // ㅌ이 3획인 경우(ㅁ과 같다)
					break;
				case 17: // ㅍ
					first = "ㅍ";
					if(after_x[1]+(size_x/10)<before_x[2])
						cnt1 = 2;
					else cnt1 = 3;
					// if() 애매해서 보류
					break;
				default: // ㅎ
					first = "ㅎ";
					if (Math.abs(after_x[1] - before_x[2]) + Math.abs(after_y[1] - before_y[2]) < (size_x + size_y) / 10)
						cnt1 = 2;// ㅎ이 3획인 경우(세 번째 획의 시작점과 끝점의 좌표가 유사한가?)
					else
						cnt1 = 0;
					break;
				}
				switch ((uni % 588) / 28) { //중성은 알고리즘은 필요 없고 어떤 모음인지만 함수에 전달
				case 0:
					second = "ㅏ";
					break;
				case 1:
					second = "ㅐ";
					break;
				case 2:
					second = "ㅑ";
					break;
				case 3:
					second = "ㅒ";
					break;
				case 4:
					second = "ㅓ";
					break;
				case 5:
					second = "ㅔ";
					break;
				case 6:
					second = "ㅕ";
					break;
				case 7:
					second = "ㅖ";
					break;
				case 8:
					second = "ㅗ";
					break;
				case 9:
					second = "ㅘ";
					break;
				case 10:
					second = "ㅙ";
					break;
				case 11:
					second = "ㅚ";
					break;
				case 12:
					second = "ㅛ";
					break;
				case 13:
					second = "ㅜ";
					break;
				case 14:
					second = "ㅝ";
					break;
				case 15:
					second = "ㅞ";
					break;
				case 16:
					second = "ㅟ";
					break;
				case 17:
					second = "ㅠ";
					break;
				case 18:
					second = "ㅡ";
					break;
				case 19:
					second = "ㅢ";
					break;
				default:
					second = "ㅣ";
					break;
				}
				if (uni % 28 != 0) // 초성은 무조건 분리하되 타입이 3보다 큰 경우(=받침이 있는 경우)엔 종성도 찾아낸다
				{
					switch (uni % 28) {
					case 1: //초성을 찾는 알고리즘과 유사하게 만들면 되며 0부터가 아닌 numOfLineIndex부터 역순으로 생각
						third = "ㄱ";
						if (Math.abs(after_y[numOfLineIndex-1] - before_y[numOfLineIndex-1]) < size_y / 20 && Math.abs(after_x[numOfLineIndex-1] - before_x[numOfLineIndex-1]) < size_x / 20)
							cnt2 = numOfLineIndex - 2;//2번만에 쓴것
						else
							cnt2 = numOfLineIndex - 1;//1번만에 쓴것
						break;
					case 2:
						third = "ㄲ";
						if (Math.abs(after_y[numOfLineIndex-1] - before_y[numOfLineIndex-1]) < size_y / 20 && Math.abs(after_x[numOfLineIndex-1] - before_x[numOfLineIndex-1]) < size_x / 20)
							cnt2 = numOfLineIndex - 4;
						else
							cnt2 = numOfLineIndex - 2;
						break;
					case 3://skip
						third = "ㄳ";
						break;
					case 4:
						third = "ㄴ";
						if (Math.abs(after_y[numOfLineIndex-1] - before_y[numOfLineIndex-1]) < size_y / 20 && Math.abs(after_x[numOfLineIndex-1] - before_x[numOfLineIndex-1]) < size_x / 20)
							cnt2 = numOfLineIndex - 2;
						else
							cnt2 = numOfLineIndex - 1;
						break;
					case 5://skip
						third = "ㄵ";
						break;
					case 6:
						third = "ㄶ";
						break;
					case 7:
						third = "ㄷ";
						if(Math.abs(before_y[numOfLineIndex-1]-after_y[numOfLineIndex-1])<size_y/20)
							cnt2=numOfLineIndex-2;//2획
						else
							cnt2=numOfLineIndex-1;//1획
						break;
					case 8:
						third = "ㄹ";
						if(Math.abs(after_y[numOfLineIndex-2]-after_y[numOfLineIndex-1])<size_y/20)
							cnt2=numOfLineIndex-3;
						else
							cnt2=numOfLineIndex-1;
						
						break;
					case 9:
						third = "ㄺ";
						break;
					case 10:
						third = "ㄻ";
						break;
					case 11:
						third = "ㄼ";
						break;
					case 12:
						third = "ㄽ";
						break;
					case 13:
						third = "ㄾ";
						break;
					case 14:
						third = "ㄿ";
						break;
					case 15:
						third = "ㅀ";
						break;
					case 16:
						third = "ㅁ";
						if(before_y[numOfLineIndex-3]<after_y[numOfLineIndex-2])
							cnt2=numOfLineIndex-3;
						else
							cnt2=numOfLineIndex-1;
						break;
					case 17:
						third = "ㅂ";
						if(before_x[numOfLineIndex-4]<after_x[numOfLineIndex-3])
						{
							
							if(before_y[numOfLineIndex-3]<after_y[numOfLineIndex-2])
								cnt2=numOfLineIndex-4;
							
						}
						
//						else if(before_x[numOfLineIndex-2]>after_x[numOfLineIndex-1])
//							cnt2=numOfLineIndex-2;
						else
							cnt2=numOfLineIndex-2;
								
						
						break;
					case 18:
						third = "ㅄ";
						break;
						
					case 19://x좌표 비교
						third = "ㅅ";
						if(after_x[numOfLineIndex-1]>before_x[numOfLineIndex-2])
							cnt2=numOfLineIndex-2;
						else
							cnt2=numOfLineIndex-1;
						break;
						
					case 20://x좌표 비교
						third = "ㅆ";
						if(after_x[numOfLineIndex-1]>before_x[numOfLineIndex-2])
						{
							if(after_x[numOfLineIndex-3]>before_x[numOfLineIndex-4])
							{
								cnt2=numOfLineIndex-4;
							}
							else
								cnt2=numOfLineIndex-3;
						}
						else
						{
							if(after_x[numOfLineIndex-3]>before_x[numOfLineIndex-4])
							{
								cnt2=numOfLineIndex-3;
							}
							else
							{
								cnt2=numOfLineIndex-2;
							}
						}
						break;
					case 21:
						third = "ㅇ";
						//무조건 한 획에 그린다
						cnt2=numOfLineIndex-1;
						break;
						
					case 22://x좌표 비교
						third = "ㅈ";
						if(Math.abs(after_x[numOfLineIndex-1])>Math.abs(before_x[numOfLineIndex-2]))
							cnt2=numOfLineIndex-2;
						else
							cnt2=numOfLineIndex-1;
						break;
						
					case 23:
						third = "ㅊ";
						//3획에 쓰는 경우
						if(Math.abs(before_x[numOfLineIndex-3])>Math.abs(after_x[numOfLineIndex-2]))
						{
							if(Math.abs(after_x[numOfLineIndex-1])>Math.abs(before_x[numOfLineIndex-2]))
								cnt2=numOfLineIndex-3;
							else
								cnt2=numOfLineIndex-2;
						}
						else
							cnt2=numOfLineIndex-1;
							
						break;
						
					case 24:
						third = "ㅋ";
						if(Math.abs(before_x[numOfLineIndex-3]-after_x[numOfLineIndex-2])<size_y/30)
							cnt2=numOfLineIndex-3;//정자로 쓰는 경우
						else
							cnt2=numOfLineIndex-2;//1획,2획 이어쓰는 경우
						break;
						
					case 25:
						third = "ㅌ";
						cnt2=numOfLineIndex-3;
						break;
						
					case 26:
						third = "ㅍ";
						if(before_x[numOfLineIndex-2]>after_x[numOfLineIndex-1])
							cnt2=numOfLineIndex-4;//정자로 쓴 경우
						else
							cnt2=numOfLineIndex-3;//3번째 획 이어쓰는 경우
						break;
						
					default:
						third = "ㅎ";
						//정자로 쓰는 경우
						if(before_x[numOfLineIndex-3]>after_x[numOfLineIndex-2])
						{
							if(after_x[numOfLineIndex-2]<after_x[numOfLineIndex-1])
							{
								cnt2=numOfLineIndex-3;
							}
						}
						else//2획,3획 이어쓰는 경우
							cnt2=numOfLineIndex-2;
						break;
					}
					//함수 호출
					devide(cnt1, cnt2, numOfLineIndex, first, second, third); //종성이 있는 경우
				} else
					devide(cnt1, numOfLineIndex, first, second); //종성이 없는 경우

			}
		}

		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// 이미지 그리기
	public void Draw(BufferedImage img) {

		Graphics2D g = img.createGraphics();

		// 선 굵기와 색상
		g.setStroke(new BasicStroke(10, BasicStroke.CAP_ROUND, 0));
		g.setColor(Color.BLACK);

		// 좌표를 바탕으로 그림 그리기
		for (int i = 0; i < index - 1; i++) {

			if (x[i] != 0.0 && y[i] != 0.0 && x[i + 1] != 0.0 && y[i + 1] != 0.0)// 다음 좌표도 0.0이 아닐때만 좌표의 그림을 그린다
			{
				g.drawLine((int) x[i], (int) y[i], (int) x[i + 1], (int) y[i + 1]);
			}
		}

	}

	public void Draw2(BufferedImage img, int start, int end, float min_x, float min_y) {

		Graphics2D g = img.createGraphics();

		// 선 굵기와 색상
		g.setStroke(new BasicStroke(30, BasicStroke.CAP_ROUND, 0));
		g.setColor(Color.BLACK);


		// 좌표를 바탕으로 그림 그리기
		for (int i = start; i < end; i++) {

			if (x[i] != 0.0 && y[i] != 0.0 && x[i + 1] != 0.0 && y[i + 1] != 0.0) // 다음 좌표도 0.0이 아닐때만 좌표의 그림을 그린다
			{
				g.drawLine((int) (x[i] - min_x + 30), (int) (y[i] - min_y + 30), (int) (x[i + 1] - min_x + 30),
						(int) (y[i + 1] - min_y + 30));
			}
		}
	}

	public BufferedImage reSize(BufferedImage img) {

		// 이미지 28x28로 리사이즈
		Image resizeImage = img.getScaledInstance(28, 28, Image.SCALE_SMOOTH);
		BufferedImage newImage = new BufferedImage(28, 28, BufferedImage.TYPE_INT_RGB);
		Graphics g = newImage.getGraphics();
		g.drawImage(resizeImage, 0, 0, null);
		g.dispose();

		return newImage;
	}

	public boolean isSimilar(int index1, int index2) { //index1번째 획의 끝점과 index2번째 획의 시작점이 가까운가?
		if(Math.abs(before_x[index1] - after_x[index2-1])<(size_x / 20)&&Math.abs(before_y[index1]-after_y[index2-1])<(size_y/20)) 
			return true;
		else
			return false;
	}
	
	public float calcSize(float max_x, float min_x, float max_y, float min_y) {
		float size_x, size_y, size;
		size_x = Math.abs(max_x - min_x);
		size_y = Math.abs(max_y - min_y);
		if (size_x > size_y)
			size = size_x;
		else
			size = size_y;

		// 글자가 잘리지 않게 하기 위해, 사이즈의 크기를 늘려준다.
		size += 60;
		return size;
	}

	public void devide(int cnt1, int cnt2, String first, String second) { //종성이 없는 경우
		BufferedImage newImage;
		BufferedImage img1;
		BufferedImage img2;
		int cnt = 0, temp = 0, numbering = 0;
		
		for (int i = 0; i < index; i++) {
			// 분기점을 만났을 때
			if (x[i] == 0.0 && y[i] == 0.0) {
				// 이미지 저장
				try {
					if (cnt == cnt1) {
						size = calcSize(max_x, min_x, max_y, min_y);
						// 이미지 그리는 함수 호출
						img1 = new BufferedImage((int) size, (int) size, BufferedImage.TYPE_INT_RGB);

						// 디폴트가 검은 배경이기 때문에, 각 픽셀들을 하얀색으로 바꿔준다.
						for (int k = 0; k < size - 1; k++)
							for (int l = 0; l < size - 1; l++)
								img1.setRGB(k, l, Color.WHITE.getRGB());

						// 이미지에 그림 그리는 함수 호출
						Draw2(img1, temp, i, min_x, min_y);

						newImage = reSize(img1);

						// 이미지 저장
						while(true) {
							File f = new File(dir + first + "(" + numbering + ").bmp");
							if(f.exists()) numbering++;
							else break;
								}
						
						ImageIO.write(newImage, "BMP", new File(dir + first + "(" + numbering + ").bmp"));
						numbering = 0;

						// 다음 시작점 저장
						temp = i;

						// 초기화
						max_x = 0;
						max_y = 0;
						min_x = x[i + 1];
						min_y = y[i + 1];
					}

					if (cnt == cnt2) {
						size = calcSize(max_x, min_x, max_y, min_y);

						img2 = new BufferedImage((int) size, (int) size, BufferedImage.TYPE_BYTE_BINARY);

						for (int k = 0; k < size - 1; k++)
							for (int l = 0; l < size - 1; l++)
								img2.setRGB(k, l, Color.WHITE.getRGB());

						Draw2(img2, temp, i, min_x, min_y);

						newImage = reSize(img2);

						while(true) {
							File f = new File(dir + second + "(" + numbering + ").bmp");
							if(f.exists()) numbering++;
							else break;
							}
						
						ImageIO.write(newImage, "BMP", new File(dir + second + "(" + numbering + ").bmp"));
					}
					cnt++;
				} catch (IOException e) {
					e.printStackTrace();
				}
			} else {
				if (max_x < x[i])
					max_x = x[i];
				if (max_y < y[i])
					max_y = y[i];

				if (min_x > x[i])
					min_x = x[i];
				if (min_y > y[i])
					min_y = y[i];
			}

		}
	}

	public void devide(int cnt1, int cnt2, int cnt3, String first, String second, String third) { //종성이 있는 경우
		BufferedImage newImage;
		BufferedImage img1 = new BufferedImage(1600, 1600, BufferedImage.TYPE_BYTE_BINARY);
		BufferedImage img2 = new BufferedImage(1600, 1600, BufferedImage.TYPE_BYTE_BINARY);
		BufferedImage img3 = new BufferedImage(1600, 1600, BufferedImage.TYPE_BYTE_BINARY);
		int cnt = 0, temp = 0, numbering = 0;

		for (int i = 0; i < index; i++) {
			// 분기점을 만났을 때
			if (x[i] == 0.0 && y[i] == 0.0) {
				// 이미지 저장
				try {
					if (cnt == cnt1) {
						size = calcSize(max_x, min_x, max_y, min_y);

						img1 = new BufferedImage((int) size, (int) size, BufferedImage.TYPE_INT_RGB);

						for (int k = 0; k < size - 1; k++)
							for (int l = 0; l < size - 1; l++)
								img1.setRGB(k, l, Color.WHITE.getRGB());

						Draw2(img1, temp, i, min_x, min_y);

						newImage = reSize(img1);

						while(true) {
							File f = new File(dir + first + "(" + numbering + ").bmp");
							if(f.exists()) numbering++;
							else break;
								}
						
						ImageIO.write(newImage, "BMP", new File(dir + first + "(" + numbering + ").bmp"));
						numbering = 0;

						temp = i;

						max_x = 0;
						max_y = 0;
						min_x = x[i + 1];
						min_y = y[i + 1];
					}
					if (cnt == cnt2) {
						size = calcSize(max_x, min_x, max_y, min_y);

						img2 = new BufferedImage((int) size, (int) size, BufferedImage.TYPE_INT_RGB);

						for (int k = 0; k < size - 1; k++)
							for (int l = 0; l < size - 1; l++)
								img2.setRGB(k, l, Color.WHITE.getRGB());

						Draw2(img2, temp, i, min_x, min_y);

						newImage = reSize(img2);

						while(true) {
							File f = new File(dir + second + "(" + numbering + ").bmp");
							if(f.exists()) numbering++;
							else break;
							}
						
						ImageIO.write(newImage, "BMP", new File(dir + second + "(" + numbering + ").bmp"));
						numbering = 0;

						temp = i;

						max_x = 0;
						max_y = 0;
						min_x = x[i + 1];
						min_y = y[i + 1];
					}

					if (cnt == cnt3) {
						size = calcSize(max_x, min_x, max_y, min_y);

						img3 = new BufferedImage((int) size, (int) size, BufferedImage.TYPE_INT_RGB);

						for (int k = 0; k < size - 1; k++)
							for (int l = 0; l < size - 1; l++)
								img3.setRGB(k, l, Color.WHITE.getRGB());

						Draw2(img3, temp, i, min_x, min_y);

						newImage = reSize(img3);
						
						while(true) {
						File f = new File(dir + third + "(" + numbering + ").bmp");
						if(f.exists()) numbering++;
						else break;
							}

						ImageIO.write(newImage, "BMP", new File(dir + third + "(" + numbering + ").bmp"));
					}
					cnt++;
				} catch (IOException e) {
					e.printStackTrace();
				}
			} else {
				if (max_x < x[i])
					max_x = x[i];
				if (max_y < y[i])
					max_y = y[i];

				if (min_x > x[i])
					min_x = x[i];
				if (min_y > y[i])
					min_y = y[i];
			}

		}
	}
}