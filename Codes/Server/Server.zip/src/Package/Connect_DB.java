package Package;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

//DB�� ������ �ֱ�
public class Connect_DB {
	static public Boolean Send_Done = false;

	public Connect_DB() {
		Dataset ds = null;
		makeConnection();
		fillTable(ds);
	}

	// DB �����ϱ�
	public static Connection makeConnection() {
		String url = "jdbc:mysql://127.0.0.1:3307/dataset?serverTimezone=UTC&characterEncoding=utf8&useUnicode=true&mysqlEnconding=utf8";
		String id = "root";
		String password = "admin";

		Connection con = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("드라이버 적재");
			con = DriverManager.getConnection(url, id, password);
			System.out.println("적재 완료");
		}

		catch (ClassNotFoundException e) {
			System.out.println(e.getCause());
		}

		catch (SQLException e) {
			System.out.println(e.getSQLState());
			
		}
		return con;
	}

	public static void fillTable(Dataset ds) {
		ds = new Dataset();
		try {
			Connection conn = makeConnection();
			java.sql.Statement stmt = conn.createStatement();
			

			// �迭 ������ �ֱ�->DB�� Table�� ����
			for (int i = 0; i < 5; i++) 
			{
				
				stmt.executeUpdate(
						"INSERT INTO dataset_table VALUES ('" + i + "','" +ds.str[i] + "','" + ds.info[0][i % 5][i / 5]
								+ "','" + ds.info[1][i % 5][i / 5] + "','" + ds.info[2][i % 5][i / 5] +"','"+ds.info[3][i%5][i/5]+"')");
			}

			conn.close();
			// DB���� ������ ��� �������� �÷��׷� �˸���

		} catch (SQLException e) {
			System.err.println("Caught Exception: " + e.getMessage());
		}
/*
		for (int i = 0; i < 500; i++) {
			System.out.println(ds.str[i] + " " + ds.info[0][i % 5][i / 5]);
		}
*/
	}

}
